# Libraries
library(tidyr)
library(tidyverse)
library(dplyr)
library(readr)
library(lubridate)
library(ggplot2)

# Get a list of the datasets
main_dir = file.path("C:","Users","ricar","Desktop","cQuant_Exercise")
data_files <- list.files(path = file.path(main_dir,"RawData"), pattern = NULL, 
                         all.files = TRUE, full.names = TRUE)

# Remove irrelevant filenames
data_files = data_files[3:length(data_files)]

# Import dataset A
data_A <- read.csv(data_files[1])
# head(data_A)

# Import dataset B
data_B <- read.csv(data_files[2])
# head(data_B)

# Pivot dataset A into long format
data_A <- data_A %>% pivot_longer(
  cols = starts_with("Run"),
  names_to = "Run",
  values_to = "Value"
)
# head(data_A)

# Pivot dataset B into long format
data_B <- data_B %>% pivot_longer(
  cols = starts_with("Run"),
  names_to = "Run",
  values_to = "Value"
)
# head(data_B)

# Join both datasets by the Name, Date, and Run variables
combined_data <- merge(x = data_A, y = data_B, by = c("Name", "Date", "Run"))
# head(combined_data)

# Change the column names to better reflect the data
colnames(combined_data)[which(names(combined_data) == "Value.x")] <- "Value.A"
colnames(combined_data)[which(names(combined_data) == "Value.y")] <- "Value.B"
# head(combined_data)

# Determine difference metrics for the data and add them onto the data frame
combined_data$Value_diff <- combined_data$Value.A - combined_data$Value.B
combined_data$Percent_diff <- (combined_data$Value.A - combined_data$Value.B) / combined_data$Value.A
combined_data$Abs_value_diff <- abs(combined_data$Value_diff)
combined_data$Abs_percent_diff <- abs(combined_data$Percent_diff)
# head(combined_data)

# Change the date column data type from 'character' to 'datetime
combined_data$Date <- ymd_hms(combined_data$Date)
#class(combined_data$Date)
#head(combined_data$Date)

# Calculate summary statistics by year
stats_by_year <- combined_data %>%
  mutate(Year = format(Date,"%Y")) %>%
  group_by(Year) %>%
  summarize(Min = min(Abs_value_diff), Max = max(Abs_value_diff), 
            Mean = mean(Abs_value_diff))
#head(stats_by_year)

# Calculate summary statistics by month
stats_by_month <- combined_data %>%
  mutate(Month = format(Date,"%m")) %>%
  group_by(Month) %>%
  summarize(Min = min(Abs_value_diff), Max = max(Abs_value_diff), 
            Mean = mean(Abs_value_diff))
#head(stats_by_month)

# Convert numeric month column to abbreviated month names
stats_by_month$Month <- month.abb[as.numeric(stats_by_month$Month)]

# Calculate summary statistics by day of the week
stats_by_dayofweek <- combined_data %>%
  mutate(Day = weekdays(Date)) %>%
  group_by(Day) %>%
  summarize(Min = min(Abs_value_diff), Max = max(Abs_value_diff), 
            Mean = mean(Abs_value_diff))
#head(stats_by_dayofweek)

# Calculate summary statistics by hour of the day
stats_by_hour <- combined_data %>%
  mutate(Hour = format(Date,"%H")) %>%
  group_by(Hour) %>% 
  summarize(Min = min(Abs_value_diff), Max = max(Abs_value_diff), 
            Mean = mean(Abs_value_diff))
head(stats_by_hour)

# write each summary table to a csv
write.csv(stats_by_year, file.path(main_dir, "Outputs","PriceDifferences_by_year.csv"), row.names = FALSE)
write.csv(stats_by_month, file.path(main_dir, "Outputs","PriceDifferences_by_month.csv"), row.names = FALSE)
write.csv(stats_by_dayofweek, file.path(main_dir, "Outputs","PriceDifferences_by_dayofweek.csv"), row.names = FALSE)
write.csv(stats_by_hour, file.path(main_dir, "Outputs","PriceDifferences_by_hour.csv"), row.names = FALSE)

# Visualize the trend over several years inlcuding the range in the data
n_points = length(stats_by_year$Year)
png(filename = file.path(main_dir,"Outputs","Difference_by_year_with_range.png"))
plot(1:n_points, stats_by_year$Mean,type="o",xlab="Year",ylab="|Value_A-Value_B|",
     ylim=c(0, 1.1*max(stats_by_year$Max)),xaxt="n")
axis(1,1:n_points,stats_by_year$Year)
arrows(x0=1:n_points,y0=stats_by_year$Min,x1=1:n_points,y1=stats_by_year$Max,
       angle=90,code=3,length=0.1)
dev.off()

# Visualize the trend over several years without inlcuding the range in the data
n_points = length(stats_by_year$Year)
png(filename = file.path(main_dir,"Outputs","Difference_by_year.png"))
plot(1:n_points, stats_by_year$Mean,type="o",xlab="Year",ylab="|Value_A-Value_B|",xaxt="n")
axis(1,1:n_points,stats_by_year$Year)
dev.off()

# Visualize the trend over several months inlcuding the range in the data
png(filename = file.path(main_dir,"Outputs","Difference_by_month_with_range.png"))
ggplot(stats_by_month, aes(x=Month,y=Mean, group=1))+
  geom_point() +
  geom_line() +
  geom_linerange(aes(ymin=Min,ymax=Max),color="blue") +
  scale_x_discrete(limits=stats_by_month$Month) + 
  labs(x="Month",y="|Value_A-Value_B|")
dev.off()

# Visualize the trend over several months
png(filename = file.path(main_dir,"Outputs","Difference_by_month.png"))
ggplot(stats_by_month, aes(x=Month,y=Mean, group=1))+
  geom_point() +
  geom_line() +
  scale_x_discrete(limits=stats_by_month$Month) +
  labs(x="Month",y="|Value_A-Value_B|")
dev.off()

# Visualize the trend for the days of the week inlcuding the range in the data
png(filename = file.path(main_dir,"Outputs","Difference_by_dayofweek_with_range.png"))
ggplot(stats_by_dayofweek) +
  geom_bar( aes(x=Day, y=Mean), stat="identity") +
  geom_linerange(aes(x=Day,ymin=Min,ymax=Max),color="blue") +
  labs(x="Day of Week",y="|Value_A-Value_B|")
dev.off()

# Visualize the trend for the days of the week
#png(filename = file.path(main_dir,"Outputs","Difference_by_dayofweek.png"))
#ggplot(stats_by_dayofweek) +
#  geom_bar( aes(x=Day, y=Mean,ymin=0,ymax=1.1*max(Mean)), stat="identity",fill="blue") +
#  labs(x="Day of Week",y="|Value_A-Value_B|")
#dev.off()